% Esta funcion permite calcular las aceleraciones entre 
% el metodo de jacobi modificado convencional y el implemtado
% con paralelismo.
% La salida es:
%   aceleraciones: vector con las aceleraciones
function aceleraciones = parte1_p4()
  n_proc = 6; % numero de procesadores maximo
  t_p = [1:6]; % vector donde se almacena los tiempos de paralelismo
  aceleraciones = t_p; % vector que guarda los resultados
  
  % A continuacion se mide el tiempo sin paralelismo  
  tic();
  parte1_p2();
  t_s = toc();
  
  % A continuacion se mide el tiempo con paralelismo y a diferente
  % numero de procesadores
  for i=1:n_proc
    tic();
    parte1_p3(i);
    t_p(i)= toc();
    aceleraciones(i) = t_s/t_p(i); % Se calcula la aceleracion correspondiente al numero de procesador
  endfor
endfunction