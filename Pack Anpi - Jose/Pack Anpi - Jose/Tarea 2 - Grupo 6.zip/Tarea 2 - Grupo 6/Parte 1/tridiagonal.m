% Construye una matriz diagonalmente dominante a partir de
% los parametros de entrada dados:
%  p: vector correspondiente a la diagonal inferior.
%  q: vector correspondiente a la diagonal superior.
%  m: dimension de los vectores.
% La salida es:
%  A: matriz mxm diagonalmente dominante.
function A=tridiagonal(p,q,m)
  A = zeros(m,m); % Se declara la matriz inicial
  % Define las posiciones iniciales
  A(1,1)=2*q(1);
  A(1,2)=q(1);
  A(2,1)=p(1);
  for i=2:(m-1)
    % Este ciclo popula el resto de las posiciones
    % de la matriz
    A(i,i)=2*(q(i)+p(i));
    A(i,i+1)=q(i);
    A(i+1,i)=p(i);
  endfor
  % Define las posiciones finales
  A(m,m-1)=p(m-1);
  A(m,m)=2*p(m);
endfunction

