% Implementa el metodo de Jacobi modificado
% La salida es:
%   x_0: vector de resultados
function x_0 = parte1_p2()
  % Declara las variables para construir la
  % matriz tridiagonal
  p = [1:0.1:25];
  q = [1:0.1:25];
  m = 241;
  B = tridiagonal(p, q, m); % Esta matriz es la que se va a resolver
  b = ones(m,1); % Vector de resultados del sistema de ecuaciones
  x_0=zeros(m,1); % Vector inicial de iteraciones y donde se almacena los resultados finales
  x_i = x_0; % Vector para almacenar los resultados temporales
  tol = 10**-5; % minimo error posible
  iterMax = 1000; % maximo de iteraciones posibles
  
  error = 1; % inicializamos el error
  iter =1; % inicilizamos las iteraciones
  while (error > tol && iter < iterMax )
    for i=1:m % se recorre la matriz completa
      tmp = 0;
      for j=1:m % este ciclo declara la suma de la funcion matematica
        if (j==i)
          tmp = tmp + 0;
        else
          tmp = tmp + (B(i,j) * x_0(j));
        endif
      endfor
      xvalue_i = (b(i)- tmp)*(1/B(i,i)); % se calcula el resultado en i
      x_i(i) = xvalue_i; % se almacena el resultado
    endfor
    x_0 = x_i; 
    x_i = zeros(m,1);
    iter = iter+1;
    error = norm(B*x_0 - b, 2); % se calcula el error
  endwhile
endfunction