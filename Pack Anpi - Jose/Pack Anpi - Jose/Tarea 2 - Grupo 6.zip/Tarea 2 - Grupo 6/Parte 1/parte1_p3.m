% Implementacion en paralelismo  del metodo de Jacobi modificado 
% La entrada es:
%   n_proc: numero de procesadores para evaluar la funcion
% La salida es:
%   x_0: vector de resultados de la matriz
function x_0 = parte1_p3(n_proc)
  % Se declaran las variables para declarar la matriz a analizar
  p = q = [1:0.1:25];
  m = 241;
  B = tridiagonal(p, q, m); % Esta matriz es diagonalmente dominante
  
  b = ones(m,1); % vector de resultados del sistema de ecuaciones
  x_0=zeros(m,1); % vector inicial de iteraciones
  x_i = x_0; % vector temporal de resultados en las iteraciones
  tol = 10**-5; % tolerancia minima para el error
  iterMax = 1000; % maximas iteraciones posibles
  
  error = 1; 
  iter =1;
  tmp_array = 1:m; % vector temporal para guardar resultados del paralelismo
  pkg load parallel
  while (error > tol && iter < iterMax )
    t_fun = @(i) parte1_p3_aux(b, B,x_0, m, i); % handler de la funcion a evaluar
    x_i=pararrayfun(n_proc,t_fun,tmp_array).';  % paralelismo de la funcion
    x_0 = x_i;
    x_i = zeros(m,1);
    iter = iter+1;
    error = norm(B*x_0 - b, 2);
  endwhile
endfunction