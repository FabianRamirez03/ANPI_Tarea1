% Implementacion de la funcion que 
% se evaluara por los hilos en el metodo
% de Jocobi  modificado e implmentado mediante paralelismo
% Las entradas son:
%   b: vector de resultados del sistema de ecuaciones
%   B: matriz que se desea resolver
%   x_0: vector inicial de iteraciones
%   m: dimension de la matriz cuadrada
%   i: posicion del ciclo
% La salida es:
%   xvalue_i: resultado en la iteracion i
function xvalue_i = parte1_p3_aux( b, B, x_0,m, i)
  tmp = 0;
  for j=1:m % ciclo que obtiene la suma de la funcion matematica
    if (j!=i)
      tmp = tmp + (B(i,j) * x_0(j));
    endif
  endfor
  xvalue_i = (b(i)- tmp)*(1/B(i,i)); % calculo del valor final
endfunction