#include <iostream>
#include "armadillo"
#include <math.h>

using namespace std;
using namespace arma;


Mat<double> pseudoinversa() {
    mat A;

    A << 1 << 0.415 << pow(0.4152, 2) << endr
      << 1 << 0.403 << pow(0.4032, 2) << endr
      << 1 << 0.390 << pow(0.3902, 2) << endr
      << 1 << 0.377 << pow(0.3772, 2) << endr
      << 1 << 0.363 << pow(0.3632, 2) << endr
      << 1 << 0.349 << pow(0.3492, 2) << endr
      << 1 << 0.334 << pow(0.3342, 2) << endr
      << 1 << 0.319 << pow(0.3192, 2) << endr
      << 1 << 0.302 << pow(0.3022, 2) << endr
      << 1 << 0.267 << pow(0.2672, 2) << endr
      << 1 << 0.247 << pow(0.2472, 2) << endr
      << 1 << 0.225 << pow(0.2252, 2) << endr
      << 1 << 0.202 << pow(0.2022, 2) << endr
      << 1 << 0.334 << pow(0.3342, 2) << endr
      << 1 << 0.175 << pow(0.1752, 2) << endr
      << 1 << 0.142 << pow(0.1422, 2) << endr
      << 1 << 0.101 << pow(0.1012, 2) << endr
      << 1 << 0.000 << pow(0.0002, 2) << endr;


    // Constantes del documento
    long double a_0 = 5 * pow(10,-10);
    long double a_1 = 2 * pow(10,-11);

    // Valores iniciales de la matriz
    mat x_0 = a_0 * A.t();
    mat x_1 = a_1 * A.t();

    long double tol = pow(10,-5);

    mat x_prev = x_0;
    mat x_current = x_1;
    mat x_next = x_prev + x_current - (x_prev * A) * x_current;

    // Error
    long double error = norm((A * x_current) * A - A,"fro");

    // Calculo de la pseudoinversa
    while(error > tol){

        x_prev = x_current;
        x_current = x_next;
        x_next = x_prev + x_current - (x_prev * A) * x_current;

        error = norm((A * x_current) * A - A,"fro");

    }
    return x_current;
}


int main() {
    mat b;

    b << 0.85 << endr
      << 0.80 << endr
      << 0.75 << endr
      << 0.70 << endr
      << 0.65 << endr
      << 0.60 << endr
      << 0.55 << endr
      << 0.50 << endr
      << 0.45 << endr
      << 0.40 << endr
      << 0.35 << endr
      << 0.30 << endr
      << 0.25 << endr
      << 0.20 << endr
      << 0.15 << endr
      << 0.10 << endr
      << 0.05 << endr
      << 0.00 << endr;

    mat A = pseudoinversa();
    mat C;
    C = A * b;
    C.print("Parametros de funcion");

    cout << "Gravedad: " << 2 * C.rows(2,2) << endl;;

    return 0;
}
