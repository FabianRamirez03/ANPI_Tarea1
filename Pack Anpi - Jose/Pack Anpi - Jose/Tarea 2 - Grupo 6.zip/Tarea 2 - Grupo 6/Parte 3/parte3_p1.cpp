#include <iostream>
#include "armadillo"
#include <math.h>

using namespace std;
using namespace arma;

// Funcion para llenar la matriz
mat fillMatrix() {
    mat A(45, 30);

    for (int i = 0; i < 45; ++i) {
        for (int j = 0; j < 30; ++j) {
            A(i, j) = pow(i,2) + pow(j,2);
        }
    }
    return A;
}



int main() {
    mat A = fillMatrix();

    // Constantes del documento
    long double a_0 = 5 * pow(10,-10);
    long double a_1 = 2 * pow(10,-11);

    // Valores iniciales de la matriz
    mat x_0 = a_0 * A.t();
    mat x_1 = a_1 * A.t();

    long double tol = pow(10,-5);

    mat x_prev = x_0;
    mat x_current = x_1;
    mat x_next = x_prev + x_current - (x_prev * A) * x_current;

    // Error
    long double error = norm((A * x_current) * A - A,"fro");

    // Calculo de la pseudoinversa
    while(error > tol){

        x_prev = x_current;
        x_current = x_next;
        x_next = x_prev + x_current - (x_prev * A) * x_current;

        error = norm((A * x_current) * A - A,"fro");

    }
    x_current.print("Matriz pseudoinversa de A:");
    return 0;
}
